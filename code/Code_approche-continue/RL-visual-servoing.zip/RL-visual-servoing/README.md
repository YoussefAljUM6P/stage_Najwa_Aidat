# Asservissement visuel par apprentissage par renforcement (A3C / PPO)

Ce dossier contient la version script du notebook Kaggle `final-version-123.ipynb`.
Il regroupe une série d'expériences d'asservissement visuel dans une scène 3D
reconstruite par **Gaussian Splatting** (scène *room* de Mip-NeRF 360) : un agent
contrôle une caméra virtuelle (translation + rotation) et doit rejoindre une pose
cible. Deux algorithmes acteur-critique sont comparés, **A3C** et **PPO**.

Les expériences vont d'une formulation « pose → pose » (l'agent connaît sa pose et
celle de la cible) jusqu'à une formulation **visuelle**, où l'état est la différence
entre les features ResNet-18 de l'image courante et de l'image cible, toutes deux
rendues par gsplat.

## Structure

```
RL-visual-servoing/
├── README.md
├── requirements.txt
├── config.py        chemins, intrinsèques caméra, transformation COLMAP -> nerfstudio
├── gs_scene.py      chargement du .ply, conversions de poses, rendu gsplat
├── envs.py          les 7 environnements Gymnasium
├── models.py        ActorCriticMLP, ActorCritic, ResNetFeatureExtractor
├── algorithms.py    boucles d'entraînement A3C et PPO
├── plots.py         figures de suivi
├── train.py         point d'entrée : une expérience = une section du notebook
├── evaluate.py      évaluation des politiques (fonctions + CLI sur checkpoint)
└── visualize.py     grille des images du jeu de données, rendu d'une pose
```

## Données

Les données ne sont pas versionnées.

| Fichier | Contenu | Source |
|---|---|---|
| `splat1.ply` | Modèle Gaussian Splatting de la scène *room* (export splatfacto, SH degré 3) | Dataset Kaggle `awjantadia/mydataset1` |
| `360_v2/room/poses_bounds.npy` | Poses des caméras d'origine (format LLFF) | [Mip-NeRF 360](https://jonbarron.info/mipnerf360/) (sur Kaggle : `thnhdg/testing`) |
| `360_v2/room/images/` | Images d'origine (uniquement pour `visualize.py`) | idem |

Les positions des caméras d'origine, ramenées dans le repère du splat par la
transformation nerfstudio (`NERFSTUDIO_TRANSFORM`, `SCALE_FACTOR` dans `config.py`),
définissent l'espace de travail : tirage des positions de départ et des cibles, et
bornes des déplacements.

Par défaut les scripts cherchent les données dans `data/` ; tous les chemins
peuvent être passés en argument (`--ply`, `--poses-bounds`, `--images-dir`).

## Expériences

Chaque valeur de `--exp` reprend une section du notebook, avec ses hyperparamètres.

| `--exp` | Environnement | État | Action | Algorithmes |
|---|---|---|---|---|
| `yaw` | `VisualServoingEnvYaw` | poses courante et cible, yaw (8) | 3 translations + yaw | A3C, PPO |
| `euler` | `VisualServoingEnvEuler` | poses + yaw/pitch/roll (12) | 3 translations + 3 rotations | A3C, PPO |
| `orientation` | `OrientationOnlyEnv` | idem (12), position figée sur la cible | 3 rotations | PPO |
| `orientation_decoupled` | `OrientationOnlyEnvDecoupled` | idem | 3 rotations | PPO (+ StepLR, `max_std=0.15`) |
| `quat_toy` | `SimpleVisualServoingEnv` | erreur de position dans le repère caméra + quaternion relatif (7) | translation locale + rotvec | PPO + évaluation |
| `quat` | `QuaternionVisualServoingEnv` | idem, dans l'espace de travail réel | idem | A3C, PPO |
| `resnet` | `GSplatVisualServoingEnv` | z\* − z, features ResNet-18 normalisées (512) | 3 translations + 3 rotations | A3C, PPO + trajectoire |

**Récompense.** Dans tous les environnements, la récompense est une récompense de
progrès (diminution de la distance à la cible entre deux pas, multipliée par un
facteur), plus un bonus lorsque la cible est atteinte.

**Distances utilisées.**
- `yaw` : distance position normalisée par la diagonale de l'espace de travail + écart de yaw / 180 ;
- `euler` : distance position normalisée + distance géodésique sur SO(3) / 180 ;
- `orientation` : distance géodésique seule ; `orientation_decoupled` : moyenne des écarts yaw, pitch, roll ;
- `quat_toy`, `quat` : distance euclidienne en position + angle de la rotation relative (rad) ;
- `resnet` : distance cosinus entre features × 100.

**Cible.** Une pose cible est tirée au début du script et reste fixe pendant tout
l'entraînement. Comme dans le notebook, seule la **position** cible est fixée pour
`yaw`, `euler`, `orientation*` et `quat` (l'orientation cible est retirée à chaque
épisode) ; pour `resnet`, la pose complète est fixée.

## Utilisation

```bash
pip install -r requirements.txt

python train.py --exp euler --algo both
python train.py --exp orientation_decoupled
python train.py --exp resnet --algo ppo --ply data/splat1.ply --poses-bounds data/360_v2/room/poses_bounds.npy

python evaluate.py --checkpoint outputs/quat_toy_ppo.pt
python visualize.py dataset --images-dir data/360_v2/room/images
python visualize.py render --pose 0.1 0.0 0.2 --yaw 90
```

Chaque run écrit dans `outputs/` le checkpoint (`<exp>_<algo>.pt`, qui contient aussi
la cible), l'historique des récompenses et distances (`<exp>_<algo>_history.npz`) et
les figures. Le rendu gsplat nécessite un GPU CUDA ; seule l'expérience `resnet`
en a besoin pendant l'entraînement (pour `yaw` et `euler`, il sert uniquement à
l'aperçu de la cible, désactivable avec `--no-preview`).

## Remarques sur l'implémentation

Ces points décrivent le code tel qu'il était dans le notebook ; ils sont conservés
pour que les scripts correspondent aux résultats obtenus.

- **« A3C » est en réalité un A2C à un seul worker.** Il n'y a ni workers parallèles
  ni mises à jour asynchrones : l'agent fait une mise à jour acteur-critique avec
  avantage à la fin de chaque épisode.
- **Log-probabilités dans `ActorCritic.get_action`.** La log-proba est calculée sur
  l'action *avant* le clamp dans [-1, 1], alors que c'est l'action *clampée* qui est
  stockée et réévaluée lors de la mise à jour PPO. Pour les actions saturées, le ratio
  PPO n'est donc pas exactement 1 à la première époque. `ActorCriticMLP` n'a pas ce
  problème (log-proba de l'action clampée).
- **Convention d'Euler dans `QuaternionVisualServoingEnv`.** La séquence scipy `"yxz"`
  (minuscules = extrinsèque) ne correspond pas à `euler_to_matrix` (R_y R_x R_z), qui
  équivaut à `"YXZ"`. Cela ne change rien à l'apprentissage (l'état est un quaternion
  relatif), mais les méthodes `render_current` / `render_target` ne rendent pas
  exactement l'orientation de l'agent.
- **Évaluation de `quat_toy`.** Dans le notebook, l'évaluation était annoncée comme
  déterministe mais échantillonnait les actions. `evaluate_agent` garde ce
  comportement par défaut ; l'option `--deterministic` utilise la moyenne de la politique.
- **Pas de graine aléatoire** dans le notebook : les runs ne sont pas reproductibles à
  l'identique. `--seed` permet d'en fixer une.
- **Nom `info["mse"]`.** Hérité du notebook, il contient la distance à la cible propre
  à chaque environnement, pas une erreur quadratique moyenne.

## Différences avec le notebook

- Les deux classes nommées `VisualServoingEnvMLP` (4 DOF puis 6 DOF) sont devenues
  `VisualServoingEnvYaw` et `VisualServoingEnvEuler` ; les rendus « yaw seul » et
  « 3 rotations » sont fusionnés (`GaussianScene.render` avec pitch = roll = 0).
- Les boucles d'entraînement dupliquées ont été factorisées dans `algorithms.py`
  (mêmes hyperparamètres, choisis dans `train.run_algorithm`).
- `SimpleVisualServoingEnv` utilisait `gym` au lieu de `gymnasium` et contenait une
  variable `effective_pos_scale` jamais utilisée : tout passe par `gymnasium` et la
  variable a été retirée (comportement inchangé).
- Sur les courbes `resnet`, la ligne de seuil est placée au seuil de succès réel
  (distance cosinus × 100 < 1.0) au lieu des lignes « 0.08 m / 0.02 m » du notebook,
  qui ne correspondaient pas à cette distance.
- Les figures sont sauvegardées en PNG (et affichées seulement avec `--show`).
